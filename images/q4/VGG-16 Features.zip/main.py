import PIL
import torch, torchvision
from typing import Callable, List, Union


# Função auxiliar que controi um forward hook que coloca na lista informada o tensor com features
# produzidas por um torch.nn.Module.
def append_output_features_to(some_list: List[torch.Tensor]) -> Callable[[torch.nn.Module, torch.Tensor, torch.Tensor], Union[None, torch.Tensor]]:
    def hook(module: torch.nn.Module, input: torch.Tensor, output: torch.Tensor) -> Union[None, torch.Tensor]:
        some_list.append(output)
    return hook


# Método principal
def main():

    # Criar uma instância de torch.nn.Module que implementa uma rede VGG-16 e carregar os pesos
    # pré-treinados para esta rede. O treinamento foi feito sobre a base ImageNet, que inclui
    # 1000 classes. Para mais informações, veja https://pytorch.org/hub/pytorch_vision_vgg/
    model = torch.hub.load('pytorch/vision:v0.9.0', 'vgg16', pretrained=True)

    # Carregar o nome das classes.
    with open('imagenet_classes.txt', 'r') as file:
        classes = [s.strip() for s in file.readlines()]
    
    # Imprimir a arquitetura da rede na saída padrão só por curiosidade.
    print(model)
    print()

    # Abrir uma imagem e transformá-la conforme a especificação de resolução de entrada e
    # normalização de valores definios na especifiação rede escolhida e em seu treinamento.
    # Essa imagem inclui um cão da raça Samoyed.
    input_image = PIL.Image.open('dog.jpg')
    preprocess = torchvision.transforms.Compose([
        torchvision.transforms.Resize(256),
        torchvision.transforms.CenterCrop(224),
        torchvision.transforms.ToTensor(),
        torchvision.transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    input_tensor = preprocess(input_image)
    
    # Só temos uma imagem, que é um tensor de shape (3, 224, 224), enquanto que a rede espera um
    # tensor de shape (N, 3, 224, 224), onde N é a quantidade de imagens no batch. Logo, é preciso
    # adicionar uma dimensão a mais no nosso tensor.
    input_batch = input_tensor.unsqueeze(0)

    # Se o seu computador possui GPU com suporte a CUDA, então vale a pena processar na GPU.
    if torch.cuda.is_available():
        input_batch = input_batch.to('cuda')
        model.to('cuda')

    # Instrumentar o módulo para capturar features recebidas e produzidas por submódulos.
    computed_features = []
    model.features[23].register_forward_hook(append_output_features_to(computed_features))
    model.features[30].register_forward_hook(append_output_features_to(computed_features))
    
    # Aplicar o modelo de classificação sobre a imagem de entrada. Como não estamos em tempo de
    # treinamento então não é preciso calcular o gradiente para aplicar backpropagation
    # posteriormente.
    with torch.no_grad():
        output = model(input_batch)

    # Normalizar e mostrar os scores de confiança para cada uma das 1000 classes
    probabilities = torch.nn.functional.softmax(output[0], dim=0)
    for c, p in zip(classes, probabilities):
        print(f'{100*p:1.2f}%: {c}')
    print()


if __name__ == '__main__':
    main()
